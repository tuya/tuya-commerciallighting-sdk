package com.tuya.smart.commercial.lighting.demo.project.presenter;


import com.tuya.smart.android.mvp.presenter.BasePresenter;
import com.tuya.smart.commercial.lighting.demo.project.model.IProjectAddModel;
import com.tuya.smart.commercial.lighting.demo.project.model.ProjectAddModel;
import com.tuya.smart.commercial.lighting.demo.project.view.IProjectAddView;
import com.tuya.smart.home.sdk.bean.HomeBean;
import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;

public class ProjectAddPresenter extends BasePresenter {


    private IProjectAddModel mProjectAddModel;
    private IProjectAddView mProjectAddView;

    public ProjectAddPresenter(IProjectAddView view) {
        super(view.getContext());
        this.mProjectAddView = view;
        this.mProjectAddModel = new ProjectAddModel();
    }


    public void addProject(String projectName, String leaderName, String leaderMobile, String detailAddress) {
        mProjectAddModel.createProject(projectName, leaderName, leaderMobile, detailAddress, new ITuyaHomeResultCallback() {
            @Override
            public void onSuccess(HomeBean homeBean) {
                if (null == mProjectAddView) {
                    return;
                }
                mProjectAddView.doSaveSuccess();
            }

            @Override
            public void onError(String s, String s1) {
                if (null == mProjectAddView) {
                    return;
                }
                mProjectAddView.doSaveFailed();
            }
        });
    }


}
