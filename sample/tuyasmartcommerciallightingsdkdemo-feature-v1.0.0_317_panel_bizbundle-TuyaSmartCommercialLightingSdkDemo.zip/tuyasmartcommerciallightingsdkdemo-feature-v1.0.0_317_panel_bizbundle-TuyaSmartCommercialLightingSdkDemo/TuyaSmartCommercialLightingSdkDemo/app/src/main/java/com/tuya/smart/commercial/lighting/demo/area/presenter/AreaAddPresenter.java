package com.tuya.smart.commercial.lighting.demo.area.presenter;


import com.tuya.smart.android.mvp.presenter.BasePresenter;
import com.tuya.smart.commercial.lighting.demo.area.model.AreaAddModel;
import com.tuya.smart.commercial.lighting.demo.area.model.IAreaAddModel;
import com.tuya.smart.commercial.lighting.demo.area.view.IAreaAddView;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

public class AreaAddPresenter extends BasePresenter {

    public static final String TAG = AreaAddPresenter.class.getSimpleName();

    private final IAreaAddModel mAreaAddModel;
    private final IAreaAddView iAreaAddView;


    public AreaAddPresenter(final IAreaAddView iAreaAddView) {
        super();
        this.iAreaAddView = iAreaAddView;
        this.mAreaAddModel = new AreaAddModel(iAreaAddView.getContext());
    }

    public void getProjectConfig(long projectId) {
        mAreaAddModel.getProjectConfig(projectId, new ITuyaResultCallback<List<AreaConfig>>() {
            @Override
            public void onSuccess(List<AreaConfig> result) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.setProjectConfig(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.showToast(errorMessage);
            }
        });
    }

    public void createSubArea(long projectId, long areaId, String name) {
        mAreaAddModel.createSubArea(projectId, areaId, name, new ITuyaResultCallback<SimpleAreaBean>() {
            @Override
            public void onSuccess(SimpleAreaBean result) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.doSaveSuccess(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.doSaveFailed(errorMessage);
            }
        });
    }

    public void createParentArea(long projectId, long areaId, String name) {
        mAreaAddModel.createParentArea(projectId, areaId, name, new ITuyaResultCallback<SimpleAreaBean>() {
            @Override
            public void onSuccess(SimpleAreaBean result) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.doSaveSuccess(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaAddView) {
                    return;
                }
                iAreaAddView.doSaveFailed(errorMessage);
            }
        });
    }
}
