package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.api.service.MicroServiceManager;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.base.utils.CollectionUtils;
import com.tuya.smart.commercial.lighting.demo.common.IntentExtra;
import com.tuya.smart.commercial.lighting.demo.project.item.ProjectIndexEmpty;
import com.tuya.smart.commercial.lighting.demo.project.item.ProjectIndexFoot;
import com.tuya.smart.commercial.lighting.demo.project.item.ProjectIndexItem;
import com.tuya.smart.commercial.lighting.demo.project.presenter.ProjectIndexPresenter;
import com.tuya.smart.commercial.lighting.demo.recyclerview.adapter.BaseRVAdapter;
import com.tuya.smart.commonbiz.bizbundle.family.api.AbsBizBundleFamilyService;
import com.tuya.smart.home.sdk.bean.HomeBean;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ProjectIndexActivity extends BaseActivity implements IProjectIndexView {
    @BindView(R.id.project_index_rv)
    RecyclerView rv;

    private ProjectIndexPresenter mPresenter;
    private BaseRVAdapter<ProjectIndexItem> mAdapter;

    Unbinder unbinder;
    private ProjectIndexFoot addProjectFoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_project_index);
        unbinder = ButterKnife.bind(this);
        initToolbar();
        initTitle();
        initAdapter();
        initListener();

        initPresenter();
    }

    private void initListener() {
        mAdapter.setOnItemViewClickListener((item, sectionKey, sectionItemPosition) -> routeInfoActivity(item.getData().getHomeId()));
    }

    private void initAdapter() {
        mAdapter = new BaseRVAdapter<>();
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(mAdapter);
    }

    private void initTitle() {
        setDisplayHomeAsUpEnabled();
        setTitle(getString(R.string.cl_project_index_title));
        mToolBar.setTitleTextColor(Color.WHITE);
    }


    private void initPresenter() {
        mPresenter = new ProjectIndexPresenter(this);
    }


    private void routeAddActivity() {
        ActivityUtils.gotoActivity(this,
                ProjectAddActivity.class,
                ActivityUtils.ANIMATE_SLIDE_TOP_FROM_BOTTOM,
                false);
    }


    private void routeInfoActivity(long projectId) {
        AbsBizBundleFamilyService service = MicroServiceManager.getInstance().findServiceByInterface(AbsBizBundleFamilyService.class.getName());
        //set the current family homeId
        service.setCurrentHomeId(projectId);

        Intent intent = new Intent(this, ProjectInfoActivity.class);
        intent.putExtra(IntentExtra.KEY_PROJECT_ID, projectId);
        ActivityUtils.startActivity(this, intent, ActivityUtils.ANIMATE_SLIDE_TOP_FROM_BOTTOM, false);
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        mPresenter.getProjectList();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != unbinder) {
            unbinder.unbind();
        }
        mPresenter.onDestroy();
    }


    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void setProjectList(List<HomeBean> projectList) {
        if (CollectionUtils.isEmpty(projectList)) {
            return;
        }
        final List<ProjectIndexItem> homeItems = new ArrayList<>();
        for (HomeBean homeBean : projectList) {
            homeItems.add(new ProjectIndexItem(homeBean));
        }
        runOnUiThread(() -> {
            mAdapter.setItemViewList(homeItems);
            if (null == addProjectFoot) {
                addProjectFoot = new ProjectIndexFoot(getString(R.string.cl_project_add_title));
                addProjectFoot.setOnClickListener(v -> routeAddActivity());
                mAdapter.addFootView(addProjectFoot);
            }
        });

    }

    @Override
    public void showProjectEmptyView() {
        runOnUiThread(() -> {
            ProjectIndexEmpty emptyView = new ProjectIndexEmpty();
            emptyView.setOnAddProjectListener(v -> routeAddActivity());
            mAdapter.showEmptyView(emptyView);
        });
    }
}
