package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Context;

import com.tuya.smart.home.sdk.bean.HomeBean;

import java.util.List;

public interface IProjectIndexView {

     Context getContext();

     void  setProjectList(List<HomeBean> projectList);

     void  showProjectEmptyView();

}
