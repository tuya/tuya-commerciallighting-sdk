package com.tuya.smart.commercial.lighting.demo;

public class GlobalConstant {
    public static long CURRENT_PROJECT_ID = 0;
}
