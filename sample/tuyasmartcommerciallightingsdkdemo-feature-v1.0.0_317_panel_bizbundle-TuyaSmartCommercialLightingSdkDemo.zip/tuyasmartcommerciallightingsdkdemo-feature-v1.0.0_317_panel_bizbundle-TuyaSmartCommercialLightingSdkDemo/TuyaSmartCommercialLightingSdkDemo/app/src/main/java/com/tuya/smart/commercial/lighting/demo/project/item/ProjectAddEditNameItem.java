package com.tuya.smart.commercial.lighting.demo.project.item;

import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseItem;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;

import butterknife.BindView;

public class ProjectAddEditNameItem extends BaseItem<String> {
    @BindView(R.id.recycler_project_add_edit)
    EditText editText;
    @BindView(R.id.recycler_project_add_title)
    TextView textView;

    private static final int EDIT_VIEW_TYPE = 10;

    private String mTitleName;

    public ProjectAddEditNameItem(String title) {
        super("");
        this.mTitleName = title;
    }

    @Override
    public int getViewType() {
        return EDIT_VIEW_TYPE;
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recylcer_project_add_item;
    }

    @Override
    public void onReleaseViews(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {
    }

    @Override
    public void onSetViewsData(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {
        textView.setText(mTitleName);
    }

    public String getEditText() {
        if (null == editText) {
            return "";
        }
        String text = editText.getText().toString();
        if (TextUtils.isEmpty(text)) {
            return "";
        }
        return text.trim();
    }

    public String getTitleName() {
        return mTitleName;
    }
}
