package com.tuya.smart.commercial.lighting.demo.project.presenter;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.tuya.smart.android.mvp.presenter.BasePresenter;
import com.tuya.smart.commercial.lighting.demo.base.utils.CollectionUtils;
import com.tuya.smart.commercial.lighting.demo.project.model.IProjectIndexModel;
import com.tuya.smart.commercial.lighting.demo.project.model.ProjectIndexModel;
import com.tuya.smart.commercial.lighting.demo.project.view.IProjectIndexView;
import com.tuya.smart.home.sdk.bean.HomeBean;
import com.tuya.smart.home.sdk.callback.ITuyaGetHomeListCallback;

import java.util.List;

public class ProjectIndexPresenter extends BasePresenter {

    public static final String TAG = ProjectIndexPresenter.class.getSimpleName();

    private IProjectIndexModel mProjectIndexModel;

    private IProjectIndexView iProjectIndexView;


    public ProjectIndexPresenter(final IProjectIndexView iProjectIndexView) {
        super();
        this.iProjectIndexView = iProjectIndexView;
        this.mProjectIndexModel = new ProjectIndexModel(iProjectIndexView.getContext());

        getProjectList();
    }


    public void getProjectList() {
        mProjectIndexModel.getProjectList(new ITuyaGetHomeListCallback() {
            @Override
            public void onSuccess(List<HomeBean> list) {
                Log.i(TAG, "queryProjectList onSuccess: " + JSON.toJSONString(list));
                if (null == iProjectIndexView.getContext()) {
                    return;
                }
                if (CollectionUtils.isEmpty(list)) {
                    iProjectIndexView.showProjectEmptyView();
                } else {
                    iProjectIndexView.setProjectList(list);
                }
            }

            @Override
            public void onError(String s, String s1) {
                Log.e(TAG, "queryProjectList onError: errorCode=" + s);
            }
        });

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
