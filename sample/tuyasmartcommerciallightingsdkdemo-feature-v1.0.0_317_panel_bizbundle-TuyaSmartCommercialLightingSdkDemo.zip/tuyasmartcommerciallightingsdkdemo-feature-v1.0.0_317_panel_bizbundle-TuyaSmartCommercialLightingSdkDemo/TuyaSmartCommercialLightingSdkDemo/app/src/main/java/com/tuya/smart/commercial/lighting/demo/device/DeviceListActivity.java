package com.tuya.smart.commercial.lighting.demo.device;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.fragment.DeviceListFragment;
import com.tuya.smart.commercial.lighting.demo.common.IntentExtra;

public class DeviceListActivity extends BaseActivity {

    private long mProjectId;
    private long mAreaId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_device_management);

        Intent intent = getIntent();
        mProjectId = intent.getLongExtra(IntentExtra.KEY_PROJECT_ID, 0);
        mAreaId = intent.getLongExtra(IntentExtra.KEY_AREA_ID, 0);

        addFragment();
    }

    private void addFragment() {
        Fragment fragment = DeviceListFragment.newInstance();
        Bundle bundle = new Bundle();
        bundle.putLong("project_id", mProjectId);
        bundle.putLong("area_id", mAreaId);
        fragment.setArguments(bundle);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, DeviceListFragment.newInstance())
                .commitAllowingStateLoss();
    }
}
