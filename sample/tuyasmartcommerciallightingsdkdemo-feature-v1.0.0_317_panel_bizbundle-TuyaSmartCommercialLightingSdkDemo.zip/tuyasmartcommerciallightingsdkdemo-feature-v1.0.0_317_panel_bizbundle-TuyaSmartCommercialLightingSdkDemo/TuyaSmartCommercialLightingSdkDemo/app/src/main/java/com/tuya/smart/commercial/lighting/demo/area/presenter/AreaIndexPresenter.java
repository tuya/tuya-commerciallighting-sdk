package com.tuya.smart.commercial.lighting.demo.area.presenter;


import com.tuya.smart.android.mvp.presenter.BasePresenter;
import com.tuya.smart.commercial.lighting.demo.area.item.AreaIndexItemStyle2;
import com.tuya.smart.commercial.lighting.demo.area.model.AreaAddModel;
import com.tuya.smart.commercial.lighting.demo.area.model.AreaIndexModel;
import com.tuya.smart.commercial.lighting.demo.area.model.IAreaAddModel;
import com.tuya.smart.commercial.lighting.demo.area.model.IAreaIndexModel;
import com.tuya.smart.commercial.lighting.demo.area.view.IAreaIndexView;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.area.bean.AreaListInProjectResponse;
import com.tuya.smart.lighting.sdk.bean.AreaBean;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.ArrayList;
import java.util.List;

public class AreaIndexPresenter extends BasePresenter {

    public static final String TAG = AreaIndexPresenter.class.getSimpleName();

    private final IAreaIndexModel mAreaIndexModel;
    private final IAreaAddModel mAreaAddModel;

    private final IAreaIndexView iAreaIndexView;
    private final long mProjectId;

    public AreaIndexPresenter(long projectId, final IAreaIndexView iAreaIndexView) {
        super();
        this.iAreaIndexView = iAreaIndexView;
        this.mAreaIndexModel = new AreaIndexModel(iAreaIndexView.getContext());
        this.mAreaAddModel = new AreaAddModel(iAreaIndexView.getContext());
        this.mProjectId = projectId;
        getAreaList();
        getAreaLevels(true, true);
        getProjectConfig();
    }

    public void getAreaList() {
        mAreaIndexModel.getAreaList(mProjectId, new ITuyaResultCallback<List<AreaBean>>() {
            @Override
            public void onSuccess(List<AreaBean> result) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.setAreaList(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.showToast(errorMessage);
            }
        });
    }

    public void getAreaLevels(boolean needUnassignedArea, boolean needPublicArea) {
        mAreaIndexModel.getAreaLevels(mProjectId, needUnassignedArea, needPublicArea, new ITuyaResultCallback<AreaListInProjectResponse>() {
            @Override
            public void onSuccess(AreaListInProjectResponse result) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.setAreaLevels(result.getList());
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.showToast(errorMessage);
            }
        });
    }

    public void getProjectConfig() {
        mAreaAddModel.getProjectConfig(mProjectId, new ITuyaResultCallback<List<AreaConfig>>() {
            @Override
            public void onSuccess(List<AreaConfig> result) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.setProjectConfig(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.showToast(errorMessage);
            }
        });
    }

    public void createArea(String name, int roomLevel) {
        mAreaAddModel.createArea(mProjectId, 0, name, roomLevel, new ITuyaResultCallback<SimpleAreaBean>() {
            @Override
            public void onSuccess(SimpleAreaBean result) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.doSaveSuccess(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == iAreaIndexView) {
                    return;
                }
                iAreaIndexView.doSaveFailed(errorMessage);
            }
        });
    }
}
