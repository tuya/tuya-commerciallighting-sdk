package com.tuya.smart.commercial.lighting.demo.project.model;

import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;

public interface IProjectAddModel {

    void createProject(String projectName, String leaderName, String leaderMobile, String detailAddress, ITuyaHomeResultCallback callback);
}
