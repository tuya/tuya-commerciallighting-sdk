package com.tuya.smart.commercial.lighting.demo.project.model;

import com.tuya.smart.home.sdk.callback.ITuyaGetHomeListCallback;

public interface IProjectIndexModel {

    void getProjectList(ITuyaGetHomeListCallback callback);
}