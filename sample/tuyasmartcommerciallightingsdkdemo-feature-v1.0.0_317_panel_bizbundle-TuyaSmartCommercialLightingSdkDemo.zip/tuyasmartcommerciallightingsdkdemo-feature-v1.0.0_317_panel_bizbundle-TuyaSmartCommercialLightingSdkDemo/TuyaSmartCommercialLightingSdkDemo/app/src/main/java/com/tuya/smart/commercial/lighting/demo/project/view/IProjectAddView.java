package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Context;

public interface IProjectAddView {

    Context getContext();

    void doSaveSuccess();

    void doSaveFailed();

}
