package com.tuya.smart.commercial.lighting.demo.area.view;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.area.item.AreaIndexItemStyle1;
import com.tuya.smart.commercial.lighting.demo.area.item.AreaIndexItemStyle2;
import com.tuya.smart.commercial.lighting.demo.area.presenter.AreaIndexPresenter;
import com.tuya.smart.commercial.lighting.demo.area.util.CreateAreaUtils;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.common.IntentExtra;
import com.tuya.smart.commercial.lighting.demo.device.DeviceListActivity;
import com.tuya.smart.commercial.lighting.demo.recyclerview.adapter.BaseRVAdapter;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.lighting.sdk.anno.AreaCategory;
import com.tuya.smart.lighting.sdk.bean.AreaBean;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

import static com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils.ANIMATE_SCALE_IN;


public class AreaIndexActivity extends BaseActivity implements IAreaIndexView {
    @BindView(R.id.rv_area_list)
    RecyclerView rvAreaList;
    @BindView(R.id.rv_area_level_list)
    RecyclerView rvLevelList;

    private static final int AREA_INFO_REQUEST_CODE = 1;
    private AreaIndexPresenter mPresenter;
    private BaseRVAdapter<AreaIndexItemStyle1> adapterAreaList;
    private BaseRVAdapter<AreaIndexItemStyle2> adapterLevelList;
    private long mProjectId;
    Unbinder unbinder;
    private String levelHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_area_index);
        unbinder = ButterKnife.bind(this);
        Intent intent = getIntent();
        mProjectId = intent.getLongExtra(IntentExtra.KEY_PROJECT_ID, 0);
        initToolbar();
        initTitle();
        initAdapter();
        initListener();
        initPresenter();
    }

    private void initListener() {
        adapterAreaList.setOnItemViewClickListener((item, sectionKey, sectionItemPosition) -> {
            AreaBean data = item.getData();
            Intent intent = null;
            switch (data.getRoomSource()) {
                case AreaCategory.CUSTOM_AREA:
                    intent = new Intent(this, AreaInfoActivity.class);
                    intent.putExtra(IntentExtra.KEY_PROJECT_ID, mProjectId);
                    intent.putExtra(IntentExtra.KEY_AREA_ID, data.getAreaId());
                    ActivityUtils.startActivityForResult(this, intent, AREA_INFO_REQUEST_CODE, ANIMATE_SCALE_IN, false);
                    break;
                case AreaCategory.PUBLIC_AREA:
                case AreaCategory.UN_SUB_AREA:
                    intent = new Intent(this, DeviceListActivity.class);
                    intent.putExtras(getIntent());
                    startActivity(intent);
                    break;
            }
        });
    }

    private void initAdapter() {
        adapterAreaList = new BaseRVAdapter<>();
        rvAreaList.setLayoutManager(new LinearLayoutManager(this));
        rvAreaList.setAdapter(adapterAreaList);

        adapterLevelList = new BaseRVAdapter<>();
        rvLevelList.setLayoutManager(new LinearLayoutManager(this));
        rvLevelList.setAdapter(adapterLevelList);
    }

    private void initTitle() {
        setDisplayHomeAsUpEnabled();
        setTitle(getString(R.string.cl_area_index_title));
        mToolBar.setTitleTextColor(Color.WHITE);
    }

    private void initPresenter() {
        mPresenter = new AreaIndexPresenter(mProjectId, this);
    }

    @OnClick(R.id.btn_area_level_list)
    public void getLevelList() {
        mPresenter.getAreaLevels(true, true);
    }

    @OnClick(R.id.btn_area_list)
    public void getAreaList() {
        mPresenter.getAreaList();
    }

    @OnClick(R.id.btn_create_area)
    public void createNewArea() {
        CreateAreaUtils.createNewDialog(this, levelHint, new CreateAreaUtils.AreaInputDialogInterface() {
            @Override
            public void onPositive(DialogInterface dialog, long areaId, String areaName, int areaLevel) {
                mPresenter.createArea(areaName, areaLevel);
            }

            @Override
            public void onNegative(DialogInterface dialog) {
                dialog.dismiss();
            }
        });
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void setAreaList(List<AreaBean> areaList) {
        adapterAreaList.clearAllItemView();
        for (AreaBean item : areaList) {
            adapterAreaList.addItemView(new AreaIndexItemStyle1(item));
        }
        adapterAreaList.notifyDataSetChanged();
    }

    @Override
    public void setAreaLevels(List<SimpleAreaBean> areaList) {
        adapterLevelList.clearAllItemView();
        for (SimpleAreaBean item : areaList) {
            adapterLevelList.addItemView(new AreaIndexItemStyle2(item));
        }
        adapterLevelList.notifyDataSetChanged();
    }


    @Override
    public void doSaveFailed(String content) {
        showToast(content);
    }

    @Override
    public void setProjectConfig(List<AreaConfig> areaConfigs) {
        StringBuilder sb = new StringBuilder();
        for (AreaConfig item : areaConfigs) {
            sb.append(item.getName()).append(":").append(item.getId()).append(" ");
        }
        levelHint = sb.toString();
    }

    @Override
    public void doSaveSuccess(SimpleAreaBean simpleAreaBean) {
        AreaBean areaBean = new AreaBean();
        areaBean.setName(simpleAreaBean.getName());
        areaBean.setAreaId(simpleAreaBean.getAreaId());
        areaBean.setRoomSource(AreaCategory.CUSTOM_AREA);
        adapterAreaList.addItemView(new AreaIndexItemStyle1(areaBean));
        adapterAreaList.notifyDataSetChanged();
        adapterLevelList.addItemView(new AreaIndexItemStyle2(simpleAreaBean));
        adapterLevelList.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AREA_INFO_REQUEST_CODE && resultCode == RESULT_OK) {
            mPresenter.getAreaList();
            mPresenter.getAreaLevels(true, true);
        }
    }
}