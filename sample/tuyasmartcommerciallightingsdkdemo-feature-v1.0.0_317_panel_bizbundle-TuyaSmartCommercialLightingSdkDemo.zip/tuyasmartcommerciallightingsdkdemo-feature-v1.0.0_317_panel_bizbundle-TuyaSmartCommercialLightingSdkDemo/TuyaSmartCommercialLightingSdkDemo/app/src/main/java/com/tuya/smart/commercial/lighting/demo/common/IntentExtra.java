package com.tuya.smart.commercial.lighting.demo.common;


public class IntentExtra {

    public static final String KEY_PROJECT_ID = "project_id";
    public static final String KEY_AREA_ID = "area_id";

}
