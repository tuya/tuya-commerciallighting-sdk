package com.tuya.smart.commercial.lighting.demo.project.item;

import android.view.View;
import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseEmpty;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;

import butterknife.BindView;

public class ProjectIndexEmpty extends BaseEmpty<String> {

    @BindView(R.id.recycler_project_empty_btn)
    TextView addProjectBtn;

    public ProjectIndexEmpty() {
        super("");
    }

    @Override
    public void onSetViewsData(BaseViewHolder holder) {
        addProjectBtn.setOnClickListener(mListener);
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recycler_project_empty;
    }

    private View.OnClickListener mListener;

    public void setOnAddProjectListener(View.OnClickListener listener) {
        mListener = listener;
    }
}
