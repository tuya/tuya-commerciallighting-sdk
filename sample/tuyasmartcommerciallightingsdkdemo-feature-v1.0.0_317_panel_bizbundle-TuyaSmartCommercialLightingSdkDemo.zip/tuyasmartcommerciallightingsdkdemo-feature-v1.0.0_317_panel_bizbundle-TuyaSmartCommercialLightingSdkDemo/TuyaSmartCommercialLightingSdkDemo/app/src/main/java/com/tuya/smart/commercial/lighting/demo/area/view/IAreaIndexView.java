package com.tuya.smart.commercial.lighting.demo.area.view;


import android.content.Context;

import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.lighting.sdk.area.bean.AreaListInProjectResponse;
import com.tuya.smart.lighting.sdk.bean.AreaBean;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

public interface IAreaIndexView {

    Context getContext();

    void setAreaList(List<AreaBean> areaList);

    void setAreaLevels(List<SimpleAreaBean> areaLevels);

    void doSaveSuccess(SimpleAreaBean simpleAreaBean);

    void doSaveFailed(String content);

    void setProjectConfig(List<AreaConfig> areaConfigs);

    void showToast(String content);
}
