package com.tuya.smart.commercial.lighting.demo.area.util;


import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.base.utils.ToastUtil;
import com.tuya.smart.commercial.lighting.demo.base.utils.UIFactory;

public class CreateAreaUtils {

    /**
     * 创建空间 / Create New Area
     *
     * @param context
     * @param listener
     */
    public static void createNewDialog(Context context, String levelHint, final AreaInputDialogInterface listener) {
        final LinearLayout view = (LinearLayout) LayoutInflater.from(context).inflate(
                R.layout.cl_dialog_create_new_area, null);
        EditText etAreaName = view.findViewById(R.id.dialog_area_name_input);
        EditText etAreaLevel = view.findViewById(R.id.dialog_area_level_input);
        etAreaLevel.setHint(levelHint);
        DialogInterface.OnClickListener onClickListener = (dialog1, which) -> {
            switch (which) {
                case DialogInterface.BUTTON_POSITIVE:
                    if (listener != null) {
                        String areaName = etAreaName.getEditableText().toString();
                        String areaLevel = etAreaLevel.getEditableText().toString();
                        if (checkParams(context, "null", areaName, areaLevel)) {
                            listener.onPositive(dialog1, 0, areaName, Integer.parseInt(areaLevel));
                        }
                    }
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    if (listener != null) {
                        listener.onNegative(dialog1);
                    }
                    break;
                default:
                    break;
            }
        };
        showDialog(context, view, onClickListener);
    }

    /**
     * 移除空间 / Remove Area
     *
     * @param context
     * @param listener
     */
    public static void createAreaDialog(Context context, final AreaInputDialogInterface listener) {
        final LinearLayout view = (LinearLayout) LayoutInflater.from(context).inflate(
                R.layout.cl_dialog_create_area, null);
        EditText etAreaName = view.findViewById(R.id.dialog_area_name_input);
        DialogInterface.OnClickListener onClickListener = (dialog1, which) -> {
            switch (which) {
                case DialogInterface.BUTTON_POSITIVE:
                    if (listener != null) {
                        String areaName = etAreaName.getEditableText().toString();
                        if (checkParams(context, "0", areaName, "null")) {
                            listener.onPositive(dialog1, 0, areaName, 1);
                        }
                    }
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    if (listener != null) {
                        listener.onNegative(dialog1);
                    }
                    break;
                default:
                    break;
            }
        };
        showDialog(context, view, onClickListener);
    }

    private static void showDialog(Context context, View view, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder dialog = UIFactory.buildAlertDialog(context);
        dialog.setNegativeButton(R.string.ty_cancel, listener);
        dialog.setPositiveButton(R.string.ty_confirm, listener);
        dialog.setView(view);
        dialog.setCancelable(false);
        dialog.create().show();
    }

    public interface AreaInputDialogInterface {

        void onPositive(DialogInterface dialog, long areaId, String areaName, int areaLevel);

        void onNegative(DialogInterface dialog);
    }

    private static Boolean checkParams(Context context, String id, String name, String level) {
        if (id.isEmpty()) {
            ToastUtil.shortToast(context, "area id can not be null");
            return false;
        } else if (name.isEmpty()) {
            ToastUtil.shortToast(context, "area name can not be null");
            return false;
        } else if (level.isEmpty()) {
            ToastUtil.shortToast(context, "area level can not be null");
            return false;
        } else {
            return true;
        }
    }
}
