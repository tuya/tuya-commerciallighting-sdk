package com.tuya.smart.commercial.lighting.demo.area.view;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.area.presenter.AreaControlPresenter;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ToastUtil;
import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanWrapper;
import com.tuya.smart.commercial.lighting.demo.common.IntentExtra;
import com.tuya.smart.lighting.sdk.enums.AreaDpMode;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class AreaControlActivity extends BaseActivity implements IAreaControlView {

    private long mProjectId;
    private long mAreaId;
    private AreaControlPresenter areaControlPresenter;

    @BindView(R.id.tv_area_info)
    public TextView areaInfoView;

    private String areaInfoHolder = "areaName:%s  switch:%s  mode:%s";

    Unbinder unbinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_dialog_area_control);
        unbinder = ButterKnife.bind(this);
        initToolbar();
        initTitle();

        Intent intent = getIntent();
        mProjectId = intent.getLongExtra(IntentExtra.KEY_PROJECT_ID, 0);
        mAreaId = intent.getLongExtra(IntentExtra.KEY_AREA_ID, 0);

        areaControlPresenter = new AreaControlPresenter(mProjectId, mAreaId, this);
    }

    @OnClick(R.id.btn_switch_on)
    public void toggleSwitchOn() {
        areaControlPresenter.setSwitch(true);
    }

    @OnClick(R.id.btn_switch_off)
    public void toggleSwitchOff() {
        areaControlPresenter.setSwitch(false);
    }

    @OnClick(R.id.btn_white_mode)
    public void toggleWhiteMode() {
        areaControlPresenter.setDpMode(AreaDpMode.MODE_WHITE_LIGHT);
    }

    @OnClick(R.id.btn_colour_mode)
    public void toggleColourMode() {
        areaControlPresenter.setDpMode(AreaDpMode.MDOE_COLORFUL_LIGHT);
    }

    @OnClick(R.id.btn_scene_mode)
    public void toggleSceneMode() {
        areaControlPresenter.setDpMode(AreaDpMode.MODE_SCENE);
    }

    private void initTitle() {
        setDisplayHomeAsUpEnabled();
        setTitle(getString(R.string.cl_area_control));
        mToolBar.setTitleTextColor(Color.WHITE);
    }


    @Override
    public void setAreaInfo(AreaBeanWrapper areaBean) {
        areaInfoView.setText(String.format(areaInfoHolder, areaBean.getName(),
                areaBean.isSwitchOpen() ? "ON" : "OFF", areaBean.getAreaDpMode().getDesc()));
    }

    @Override
    public void toast(String message) {
        ToastUtil.showToast(this, message);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }
}
