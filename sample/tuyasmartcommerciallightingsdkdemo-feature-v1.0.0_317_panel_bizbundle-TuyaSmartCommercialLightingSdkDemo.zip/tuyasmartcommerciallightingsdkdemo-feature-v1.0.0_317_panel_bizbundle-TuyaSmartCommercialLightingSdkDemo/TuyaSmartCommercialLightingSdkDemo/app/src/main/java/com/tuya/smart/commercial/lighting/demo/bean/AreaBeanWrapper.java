package com.tuya.smart.commercial.lighting.demo.bean;


import com.tuya.smart.lighting.sdk.bean.AreaBean;

/**
 * 商照DeviceBean
 */
public class AreaBeanWrapper extends LightingDpsWrapper {

    /** 区域数据 */
    private AreaBean areaBean;

    /** Tag是否被选中 在设置区域和功率值弹窗中使用到 */
    private boolean selected;

    public AreaBeanWrapper() {
    }

    public AreaBeanWrapper(AreaBean areaBean) {
        this.areaBean = areaBean;
    }

    public AreaBean getAreaBean() {
        return areaBean;
    }

    public void setAreaBean(AreaBean deviceBean) {
        this.areaBean = deviceBean;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }


    public void reset() {
        super.reset();
        areaBean = null;
    }

}
