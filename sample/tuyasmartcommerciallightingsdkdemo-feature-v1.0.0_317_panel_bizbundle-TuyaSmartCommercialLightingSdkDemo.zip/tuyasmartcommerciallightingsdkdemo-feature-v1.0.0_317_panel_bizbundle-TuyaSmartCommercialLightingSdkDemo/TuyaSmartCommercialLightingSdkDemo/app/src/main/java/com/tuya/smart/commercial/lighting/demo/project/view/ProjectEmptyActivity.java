package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Intent;
import android.os.Bundle;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.android.user.api.ILogoutCallback;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.base.utils.LoginHelper;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class ProjectEmptyActivity extends BaseActivity {

    private Unbinder unbinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_project_empty);
        unbinder = ButterKnife.bind(this);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }


    @Override
    public void onBackPressed() {

    }

    @OnClick(R.id.activity_project_logout_btn)
    public void onLogoutClick() {
        TuyaCommercialLightingSdk.getLightingUserManager().logout(new ILogoutCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(String errorCode, String errorMsg) {

            }
        });
        LoginHelper.reLogin(this, false);
    }


    @OnClick(R.id.activity_project_empty_btn)
    public void onFamilyEmptyClick() {
        Intent intent = new Intent(this, ProjectAddActivity.class);
        intent.putExtra(ProjectAddActivity.KEY_EMPTY_PROJECT, true);
        ActivityUtils.startActivity(this, intent, ActivityUtils.ANIMATE_SLIDE_TOP_FROM_BOTTOM,
                false);
    }
}
