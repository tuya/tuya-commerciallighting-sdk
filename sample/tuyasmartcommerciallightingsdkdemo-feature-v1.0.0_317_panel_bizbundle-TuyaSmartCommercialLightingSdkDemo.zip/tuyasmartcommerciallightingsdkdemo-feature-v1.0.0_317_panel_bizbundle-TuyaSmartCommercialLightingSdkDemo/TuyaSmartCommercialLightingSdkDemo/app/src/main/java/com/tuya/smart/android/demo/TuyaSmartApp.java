package com.tuya.smart.android.demo;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.multidex.MultiDexApplication;

import com.tuya.smart.android.common.utils.L;
import com.tuya.smart.android.demo.base.utils.ToastUtil;
import com.tuya.smart.android.panel.TuyaPanelSDK;
import com.tuya.smart.android.panel.api.ITuyaPressedRightMenuListener;
import com.tuya.smart.api.router.UrlBuilder;
import com.tuya.smart.api.service.RouteEventListener;
import com.tuya.smart.commercial.lighting.demo.BizBundleProjectServiceImpl;
import com.tuya.smart.commercial.lighting.demo.login.activity.LoginWithUidActivity;
import com.tuya.smart.commonbiz.bizbundle.family.api.AbsBizBundleFamilyService;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.sdk.api.INeedLoginListener;
import com.tuya.smart.wrapper.api.TuyaWrapper;


public class TuyaSmartApp extends MultiDexApplication {

    private static final String TAG = "TuyaSmartApp";

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        L.d(TAG, "onCreate " + getProcessName(this));

        TuyaCommercialLightingSdk.setDebugMode(true);
        TuyaCommercialLightingSdk.init(this);

        //TODO 此处需填写appkey和appsecret
        TuyaPanelSDK.init(this, "", "");

        TuyaPanelSDK.getPanelInstance().setPressedRightMenuListener(new ITuyaPressedRightMenuListener() {
            @Override
            public void onPressedRightMenu(String s, long groupId) {
                Toast.makeText(TuyaPanelSDK.getCurrentActivity(), s + " " + groupId, Toast.LENGTH_SHORT).show();
            }
        });

        TuyaCommercialLightingSdk.setOnNeedLoginListener(new INeedLoginListener() {
            @Override
            public void onNeedLogin(Context context) {
                Intent intent = new Intent(context, LoginWithUidActivity.class);
                if (!(context instanceof Activity)) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                startActivity(intent);
            }
        });

        // fail router listener
        TuyaWrapper.init(this, new RouteEventListener() {
            @Override
            public void onFaild(int errorCode, UrlBuilder urlBuilder) {
                ToastUtil.shortToast(TuyaPanelSDK.getCurrentActivity(), urlBuilder.originUrl);
            }
        });
        //register FamilyService,set the current family homeId,BizBundleFamilyServiceImpl is sample code
        TuyaWrapper.registerService(AbsBizBundleFamilyService.class, new BizBundleProjectServiceImpl());
    }

    public static String getProcessName(Context context) {
        int pid = android.os.Process.myPid();
        ActivityManager mActivityManager = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo appProcess : mActivityManager
                .getRunningAppProcesses()) {
            if (appProcess.pid == pid) {
                return appProcess.processName;
            }
        }
        return "";
    }

    private static Context context;

    public static Context getAppContext() {
        return context;
    }


}
