package com.tuya.smart.commercial.lighting.demo.area.model;

import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanWrapper;

import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.api.ILightingStandardAreaDpsManager;
import com.tuya.smart.lighting.sdk.enums.AreaDpMode;
import com.tuya.smart.sdk.api.IResultCallback;

public class AreaControlModel {

    /**
     * 设置模式
     *
     * @param projectId
     * @param areaBeanWrapper
     * @param areaDpMode
     * @param listener
     */
    public void setDpMode(long projectId, AreaBeanWrapper areaBeanWrapper, AreaDpMode areaDpMode, IResultCallback listener) {
        ILightingStandardAreaDpsManager dpsManager = TuyaCommercialLightingSdk
                .newAreaInstance(projectId, areaBeanWrapper.getAreaBean().getAreaId())
                .getLightingStandardAreaDpsManagerInstance();
        dpsManager.requestMode(areaDpMode, listener);
    }


    /**
     * 设置开关
     *
     * @param projectId
     * @param areaBeanWrapper
     * @param open
     * @param listener
     */
    public void setSwitch(long projectId, AreaBeanWrapper areaBeanWrapper, boolean open, IResultCallback listener) {
        if (null == areaBeanWrapper.getAreaBean()) {
            return;
        }
        ILightingStandardAreaDpsManager lightingStandardAreaDpsManager = TuyaCommercialLightingSdk
                .newAreaInstance(projectId, areaBeanWrapper.getAreaBean().getAreaId())
                .getLightingStandardAreaDpsManagerInstance();
        lightingStandardAreaDpsManager.requestSwitchStatus(open, listener);
    }

    /**
     * 设置亮度
     *
     * @param projectId
     * @param areaBeanWrapper
     * @param value
     * @param listener
     */
    public void setBrightness(long projectId, AreaBeanWrapper areaBeanWrapper, int value, IResultCallback listener) {
        if (null == areaBeanWrapper.getAreaBean()) {
            return;
        }
        ILightingStandardAreaDpsManager lightingStandardAreaDpsManager = TuyaCommercialLightingSdk
                .newAreaInstance(projectId, areaBeanWrapper.getAreaBean().getAreaId()).getLightingStandardAreaDpsManagerInstance();
        lightingStandardAreaDpsManager.requestBrightPercent(value, listener);

    }

    /**
     * 设置色温
     *
     * @param projectId
     * @param areaBeanWrapper
     * @param temp
     * @param listener
     */
    public void setTemperature(long projectId, AreaBeanWrapper areaBeanWrapper, int temp, IResultCallback listener) {
        if (null == areaBeanWrapper.getAreaBean()) {
            return;
        }
        ILightingStandardAreaDpsManager dpsManager = TuyaCommercialLightingSdk
                .newAreaInstance(projectId, areaBeanWrapper.getAreaBean().getAreaId()).getLightingStandardAreaDpsManagerInstance();
        dpsManager.requestTemperaturePercent(temp, listener);
    }

    /**
     * 设置彩光
     *
     * @param projectId
     * @param areaBeanWrapper
     * @param colorData
     * @param listener
     */
    public void setColorData(long projectId, AreaBeanWrapper areaBeanWrapper, String colorData, IResultCallback listener) {
        if (null == areaBeanWrapper.getAreaBean()) {
            return;
        }
        ILightingStandardAreaDpsManager dpsManager = TuyaCommercialLightingSdk
                .newAreaInstance(projectId, areaBeanWrapper.getAreaBean().getAreaId())
                .getLightingStandardAreaDpsManagerInstance();
        dpsManager.requestSetColorData(colorData, listener);
    }
}
