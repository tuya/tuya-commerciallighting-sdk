package com.tuya.smart.commercial.lighting.demo;

import android.os.Bundle;
import android.view.View;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.android.user.api.ILogoutCallback;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.base.utils.LoginHelper;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;

public class LauncherActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        View projectManagementView = findViewById(R.id.btn_project_management);
        View logoutView = findViewById(R.id.btn_logout);

        projectManagementView.setOnClickListener(this);
        logoutView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_project_management:
                ActivityUtils.gotoProjectManagementActivity(this);
                break;
            case R.id.btn_logout:
                logout();
                break;
            default:
                break;
        }
    }

    private void logout() {
        TuyaCommercialLightingSdk.getLightingUserManager().logout(new ILogoutCallback() {
            @Override
            public void onSuccess() {
                LoginHelper.reLogin(LauncherActivity.this, false);
            }

            @Override
            public void onError(String code, String error) {

            }
        });
    }
}
