package com.tuya.smart.commercial.lighting.demo;

import com.tuya.smart.commonbiz.bizbundle.family.api.AbsBizBundleFamilyService;

public class BizBundleProjectServiceImpl extends AbsBizBundleFamilyService {

    private long mProjectId;

    @Override
    public long getCurrentHomeId() {
        return mProjectId;
    }

    @Override
    public void setCurrentHomeId(long homeId) {
        mProjectId = homeId;
    }

    @Override
    public void shiftCurrentFamily(long l, String s) {
        mProjectId = l;
    }
}