package com.tuya.smart.commercial.lighting.demo.project.model;

import android.content.Context;

import com.tuya.smart.android.mvp.model.BaseModel;
import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.sdk.api.IResultCallback;

public class ProjectInfoModel extends BaseModel implements IProjectInfoModel {

    public ProjectInfoModel(Context ctx) {
        super(ctx);
    }

    @Override
    public void getProjectDetail(long projectId, ITuyaHomeResultCallback callback) {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).getProjectDetail(callback);
    }

    @Override
    public void getKeyFromPassword(String password, ITuyaResultCallback<String> callback) {
        TuyaCommercialLightingSdk.getLightingUserManager().getKeyFromPassword(password, callback);
    }

    @Override
    public void updateProjectInfo(long projectId, String projectName, String leaderName, String leaderMobile, String detailAddress, final IResultCallback callback) {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).updateProjectInfo(projectName, leaderName, leaderMobile, detailAddress, callback);
    }

    @Override
    public void delete(long projectId, String key, IResultCallback callback) {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).delete(key, callback);
    }

    @Override
    public void onDestroy() {

    }
}
