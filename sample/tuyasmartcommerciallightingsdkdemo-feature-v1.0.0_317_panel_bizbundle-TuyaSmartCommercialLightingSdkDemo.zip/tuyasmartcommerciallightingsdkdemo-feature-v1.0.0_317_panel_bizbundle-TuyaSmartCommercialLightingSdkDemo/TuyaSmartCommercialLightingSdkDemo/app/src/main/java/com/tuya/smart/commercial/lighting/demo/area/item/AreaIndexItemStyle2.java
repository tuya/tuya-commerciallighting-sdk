package com.tuya.smart.commercial.lighting.demo.area.item;


import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseItem;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;

import butterknife.BindView;

public class AreaIndexItemStyle2 extends BaseItem<SimpleAreaBean> {

    @BindView(R.id.recycler_area_level_item_name)
    TextView tvName;

    public AreaIndexItemStyle2(SimpleAreaBean data) {
        super(data);
    }

    @Override
    public int getViewType() {
        return 0;
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recycler_area_level_index_item;
    }

    @Override
    public void onReleaseViews(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {

    }

    @Override
    public void onSetViewsData(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {
        tvName.setText(getData().getName());
    }
}
