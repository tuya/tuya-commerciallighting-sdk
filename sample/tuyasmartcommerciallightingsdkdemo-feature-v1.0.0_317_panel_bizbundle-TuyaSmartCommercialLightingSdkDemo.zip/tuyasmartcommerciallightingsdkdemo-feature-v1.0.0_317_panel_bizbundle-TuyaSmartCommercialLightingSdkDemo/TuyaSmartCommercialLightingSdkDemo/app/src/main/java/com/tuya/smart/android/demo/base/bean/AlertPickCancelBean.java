package com.tuya.smart.android.demo.base.bean;

/**
 * Created by letian on 15/6/13.
 */
public class AlertPickCancelBean {
    public String getHandler() {
        return handler;
    }

    public void setHandler(String handler) {
        this.handler = handler;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String title;
    private String handler;
}
