package com.tuya.smart.commercial.lighting.demo.area.view;

import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanWrapper;

public interface IAreaControlView {
    void setAreaInfo(AreaBeanWrapper areaBean);

    void toast(String message);
}
