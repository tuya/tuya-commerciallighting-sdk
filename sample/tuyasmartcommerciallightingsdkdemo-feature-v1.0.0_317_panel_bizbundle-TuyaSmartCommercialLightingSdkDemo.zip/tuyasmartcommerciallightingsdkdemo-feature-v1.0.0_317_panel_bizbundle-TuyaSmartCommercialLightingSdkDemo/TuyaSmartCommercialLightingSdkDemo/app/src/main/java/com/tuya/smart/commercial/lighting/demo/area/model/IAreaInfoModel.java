package com.tuya.smart.commercial.lighting.demo.area.model;


import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import java.util.List;

interface IAreaInfoModel {

    void getSubAreaList(long projectId, long areaId, ITuyaResultCallback<List<AreaBean>> callback);

    void getAreaInfo(long projectId, long areaId, ITuyaResultCallback<SimpleAreaBean> callback);

    AreaBean getAreaBeanInCache(long projectId, long areaId);

    void updateName(long projectId, long areaId, String name, ITuyaResultCallback<Boolean> callback);

    void delete(long projectId, long areaId, ITuyaResultCallback<Boolean> callback);
}
