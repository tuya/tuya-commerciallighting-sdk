package com.tuya.smart.commercial.lighting.demo.project.model;

import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;

public class ProjectAddModel implements IProjectAddModel {

    public static final String TAG = ProjectAddModel.class.getSimpleName();

    @Override
    public void createProject(String projectName, String leaderName, String leaderMobile, String detailAddress, ITuyaHomeResultCallback callback) {
        TuyaCommercialLightingSdk.getLightingProjectManager().createProject(
                projectName, leaderName, leaderMobile, detailAddress, callback
        );
    }
}
