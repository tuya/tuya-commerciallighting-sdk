package com.tuya.smart.commercial.lighting.demo.bean;

import com.tuya.smart.lighting.sdk.enums.AreaDpMode;
import com.tuya.smart.lighting.sdk.enums.LightDefaultSceneType;

public class LightingDpsWrapper {
    /** 亮度值 */
    private int brightness;

    /** 开关状态 true-开 false:关 */
    private boolean switchOpen;

    /** 是否是默认的区域 在设置区域和功率值弹窗中使用到 false:不是   true:是 */
    private boolean defaultArea;

    /** 色温百分比 */
    private int temperaturePercent;

    private AreaDpMode areaDpMode;

    /** 默认选中的场景类型 */
    private LightDefaultSceneType currentSceneType = LightDefaultSceneType.NONE;

    /** 颜色HSV */
    private String colorData;

    private String dps;

    private String name;

    public int getBrightness() {
        return brightness;
    }

    public void setBrightness(int brightness) {
        this.brightness = brightness;
    }

    public boolean isSwitchOpen() {
        return switchOpen;
    }

    public void setSwitchOpen(boolean switchOpen) {
        this.switchOpen = switchOpen;
    }

    public boolean isDefaultArea() {
        return defaultArea;
    }

    public void setDefaultArea(boolean defaultArea) {
        this.defaultArea = defaultArea;
    }

    public int getTemperaturePercent() {
        return temperaturePercent;
    }

    public void setTemperaturePercent(int temperaturePercent) {
        this.temperaturePercent = temperaturePercent;
    }

    public AreaDpMode getAreaDpMode() {
        return areaDpMode;
    }

    public void setAreaDpMode(AreaDpMode areaDpMode) {
        this.areaDpMode = areaDpMode;
    }

    public LightDefaultSceneType getCurrentSceneType() {
        return currentSceneType;
    }

    public void setCurrentSceneType(LightDefaultSceneType currentSceneType) {
        this.currentSceneType = currentSceneType;
    }

    public String getColorData() {
        return colorData;
    }

    public void setColorData(String colorData) {
        this.colorData = colorData;
    }

    public String getDps() {
        return dps;
    }

    public void setDps(String dps) {
        this.dps = dps;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void reset() {
        brightness = 0;
        switchOpen = false;
//        viewType = 0;
    }
}
