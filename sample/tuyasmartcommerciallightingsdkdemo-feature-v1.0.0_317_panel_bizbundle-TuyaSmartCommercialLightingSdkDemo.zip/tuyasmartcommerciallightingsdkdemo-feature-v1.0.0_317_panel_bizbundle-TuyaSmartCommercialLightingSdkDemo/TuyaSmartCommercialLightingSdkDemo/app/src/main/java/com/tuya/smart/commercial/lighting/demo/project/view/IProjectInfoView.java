package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Context;

import com.tuya.smart.home.sdk.bean.HomeBean;
import com.tuya.smart.home.sdk.bean.MemberBean;

import java.util.List;

public interface IProjectInfoView {

    Context getContext();

    long getProjectId();

    void setProjectData(HomeBean homeBean);

    void updateProjectName(String projectName);

    void updateLeaderName(String leaderName);

    void updateLeaderMobile(String leaderMobile);

    void updateAddressDetail(String addressDetail);

    void doRemoveView(boolean isSuccess);

    void showToast(String res);
}
