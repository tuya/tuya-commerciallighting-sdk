package com.tuya.smart.commercial.lighting.demo.project.item;

import android.util.Pair;
import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseItem;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;

import butterknife.BindView;

public class ProjectInfoItem extends BaseItem<Pair<String, String>> {

    @BindView(R.id.recycler_project_info_name)
    TextView nameTxt;
    @BindView(R.id.recycler_project_info_value)
    TextView valueTxt;


    public ProjectInfoItem(Pair<String, String> data) {
        super(data);
    }

    @Override
    public int getViewType() {
        return 0;
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recycler_project_info;
    }

    @Override
    public void onReleaseViews(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {

    }

    @Override
    public void onSetViewsData(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {
        nameTxt.setText(getData().first);
        valueTxt.setText(getData().second);
    }
}
