package com.tuya.smart.commercial.lighting.demo.area.model;


import android.content.Context;

import com.tuya.smart.android.mvp.model.BaseModel;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

public class AreaAddModel extends BaseModel implements IAreaAddModel {

    public static final String TAG = AreaAddModel.class.getSimpleName();

    public AreaAddModel(Context ctx) {
        super(ctx);
    }

    @Override
    public void getProjectConfig(long projectId, ITuyaResultCallback<List<AreaConfig>> callback) {
        TuyaCommercialLightingSdk.getLightingProjectManager().getProjectConfig(projectId, callback);
    }

    @Override
    public void createArea(long projectId, long currentAreaId, String name, int roomLevel, ITuyaResultCallback<SimpleAreaBean> callback) {
        TuyaCommercialLightingSdk.getLightingAreaManager().createArea(projectId, currentAreaId, name, roomLevel, callback);
    }

    @Override
    public void createSubArea(long projectId, long areaId, String subAreaName, ITuyaResultCallback<SimpleAreaBean> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).createSubArea(subAreaName, callback);
    }

    @Override
    public void createParentArea(long projectId, long areaId, String parentAreaName, ITuyaResultCallback<SimpleAreaBean> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).createParentArea(parentAreaName, callback);
    }

    @Override
    public void onDestroy() {

    }
}
