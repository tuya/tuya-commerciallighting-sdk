package com.tuya.smart.commercial.lighting.demo.area.presenter;

import com.tuya.smart.commercial.lighting.demo.area.model.AreaControlModel;
import com.tuya.smart.commercial.lighting.demo.area.model.AreaInfoModel;
import com.tuya.smart.commercial.lighting.demo.area.view.IAreaControlView;
import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanWrapper;
import com.tuya.smart.commercial.lighting.demo.utils.AreaBeanConverter;
import com.tuya.smart.lighting.sdk.bean.AreaBean;
import com.tuya.smart.lighting.sdk.enums.AreaDpMode;
import com.tuya.smart.sdk.api.IResultCallback;

public class AreaControlPresenter {
    private long projectId;
    private long areaId;
    private AreaBeanWrapper areaBeanWrapper;
    private AreaControlModel areaControlModel = new AreaControlModel();
    private final AreaInfoModel areaInfoModel = new AreaInfoModel(null);
    private IAreaControlView view;

    public AreaControlPresenter(long projectId, long areaId, IAreaControlView view) {
        this.projectId = projectId;
        this.areaId = areaId;
        this.view = view;
        init();
    }

    private void init() {
        if (areaBeanWrapper == null) {
            AreaBean areaBean = areaInfoModel.getAreaBeanInCache(projectId, areaId);
            if (areaBean == null) {
                throw new IllegalArgumentException("areaBean cannot be null");
            }

            areaBeanWrapper = AreaBeanConverter.convertAreaBean2Wrapper(projectId, areaBean);

            view.setAreaInfo(areaBeanWrapper);
        }
    }

    public void setDpMode(AreaDpMode areaDpMode) {
        init();
        areaControlModel.setDpMode(projectId, areaBeanWrapper, areaDpMode, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                view.toast(error);
            }

            @Override
            public void onSuccess() {
                areaBeanWrapper.setAreaDpMode(areaDpMode);
                view.setAreaInfo(areaBeanWrapper);
            }
        });
    }

    /**
     * 设置开关
     *
     * @param open
     */
    public void setSwitch(boolean open) {
        init();
        areaControlModel.setSwitch(projectId, areaBeanWrapper, open, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                view.toast(error);
            }

            @Override
            public void onSuccess() {
                areaBeanWrapper.setSwitchOpen(open);
                view.setAreaInfo(areaBeanWrapper);
            }
        });
    }

    /**
     * 设置亮度
     *
     * @param value
     */
    public void setBrightness(int value) {
        init();
        areaControlModel.setBrightness(projectId, areaBeanWrapper, value, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                view.toast(error);
            }

            @Override
            public void onSuccess() {
                areaBeanWrapper.setBrightness(value);
                view.setAreaInfo(areaBeanWrapper);
            }
        });
    }

    /**
     * 设置色温
     *
     * @param temp
     */
    public void setTemperature(int temp) {
        init();
        areaControlModel.setTemperature(projectId, areaBeanWrapper, temp, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                view.toast(error);
            }

            @Override
            public void onSuccess() {
                areaBeanWrapper.setTemperaturePercent(temp);
                view.setAreaInfo(areaBeanWrapper);
            }
        });
    }

    /**
     * 设置彩光
     *
     * @param colorData
     */
    public void setColorData(String colorData) {
        init();
        areaControlModel.setColorData(projectId, areaBeanWrapper, colorData, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                view.toast(error);
            }

            @Override
            public void onSuccess() {
                areaBeanWrapper.setColorData(colorData);
                view.setAreaInfo(areaBeanWrapper);
            }
        });
    }
}
