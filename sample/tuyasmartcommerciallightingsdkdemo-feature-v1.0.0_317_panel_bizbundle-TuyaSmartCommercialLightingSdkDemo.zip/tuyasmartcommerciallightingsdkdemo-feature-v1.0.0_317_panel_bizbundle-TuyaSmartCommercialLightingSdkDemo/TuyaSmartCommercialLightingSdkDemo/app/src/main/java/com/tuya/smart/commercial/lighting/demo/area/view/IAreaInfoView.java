package com.tuya.smart.commercial.lighting.demo.area.view;


import android.content.Context;

import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.lighting.sdk.bean.AreaBean;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

public interface IAreaInfoView {

    Context getContext();

    void setAreaData(SimpleAreaBean simpleAreaBean);

    void setSubAreaList(List<AreaBean> subAreaList);

    void updateSuccess(String name);

    void doRemoveView(boolean isSuccess);

    void createSubSuccess(SimpleAreaBean simpleAreaBean);

    void createParentSuccess(SimpleAreaBean simpleAreaBean);

    void createFailed(String content);

    void showToast(String content);
}
