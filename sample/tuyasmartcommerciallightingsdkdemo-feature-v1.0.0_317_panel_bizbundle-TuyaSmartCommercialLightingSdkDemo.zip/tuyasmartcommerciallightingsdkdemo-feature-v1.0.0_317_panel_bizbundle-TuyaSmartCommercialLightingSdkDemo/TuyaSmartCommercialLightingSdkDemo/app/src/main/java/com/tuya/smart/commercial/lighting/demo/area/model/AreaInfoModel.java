package com.tuya.smart.commercial.lighting.demo.area.model;


import android.content.Context;

import com.tuya.smart.android.mvp.model.BaseModel;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import java.util.List;

public class AreaInfoModel extends BaseModel implements IAreaInfoModel {

    public static final String TAG = AreaInfoModel.class.getSimpleName();

    public AreaInfoModel(Context ctx) {
        super(ctx);
    }

    @Override
    public void getSubAreaList(long projectId, long areaId, ITuyaResultCallback<List<AreaBean>> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).getSubAreaList(callback);
    }

    @Override
    public void getAreaInfo(long projectId, long areaId, ITuyaResultCallback<SimpleAreaBean> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).getAreaInfo(callback);
    }

    @Override
    public AreaBean getAreaBeanInCache(long projectId, long areaId) {
        return TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).getCurrentAreaBeanCache();
    }

    @Override
    public void updateName(long projectId, long areaId, String name, ITuyaResultCallback<Boolean> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).updateName(name, callback);
    }

    @Override
    public void delete(long projectId, long areaId, ITuyaResultCallback<Boolean> callback) {
        TuyaCommercialLightingSdk.newAreaInstance(projectId, areaId).delete(callback);
    }

    @Override
    public void onDestroy() {

    }
}
