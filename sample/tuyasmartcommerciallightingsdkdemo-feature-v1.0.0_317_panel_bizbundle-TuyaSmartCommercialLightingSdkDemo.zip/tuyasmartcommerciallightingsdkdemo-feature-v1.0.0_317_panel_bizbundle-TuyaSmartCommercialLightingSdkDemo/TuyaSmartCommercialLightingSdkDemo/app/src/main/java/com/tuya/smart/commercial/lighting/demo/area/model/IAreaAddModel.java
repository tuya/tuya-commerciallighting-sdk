package com.tuya.smart.commercial.lighting.demo.area.model;


import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.bean.AreaConfig;

import java.util.List;

public interface IAreaAddModel {

    void getProjectConfig(long projectId, ITuyaResultCallback<List<AreaConfig>> callback);

    void createArea(long projectId, long currentAreaId, String name, int roomLevel, ITuyaResultCallback<SimpleAreaBean> callback);

    void createSubArea(long projectId, long areaId, String subAreaName, ITuyaResultCallback<SimpleAreaBean> callback);

    void createParentArea(long projectId, long areaId, String parentAreaName, ITuyaResultCallback<SimpleAreaBean> callback);
}