package com.tuya.smart.commercial.lighting.demo.project.model;

import android.content.Context;

import com.tuya.smart.android.mvp.model.BaseModel;
import com.tuya.smart.home.sdk.callback.ITuyaGetHomeListCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;

public class ProjectIndexModel extends BaseModel implements IProjectIndexModel {

    public static final String TAG = ProjectIndexModel.class.getSimpleName();

    public ProjectIndexModel(Context ctx) {
        super(ctx);
    }

    @Override
    public void getProjectList(ITuyaGetHomeListCallback callback) {
        TuyaCommercialLightingSdk.getLightingProjectManager().getProjectList(callback);
    }

    @Override
    public void onDestroy() {

    }

}
