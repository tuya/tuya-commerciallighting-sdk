package com.tuya.smart.commercial.lighting.demo.config;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.tuya.smart.android.blemesh.api.ITuyaBlueMeshActivatorListener;
import com.tuya.smart.android.blemesh.api.ITuyaBlueMeshSearch;
import com.tuya.smart.android.blemesh.api.ITuyaBlueMeshSearchListener;
import com.tuya.smart.android.blemesh.bean.SearchDeviceBean;
import com.tuya.smart.android.blemesh.builder.SearchBuilder;
import com.tuya.smart.android.blemesh.builder.TuyaSigMeshActivatorBuilder;
import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ProgressUtil;
import com.tuya.smart.commercial.lighting.demo.base.utils.ToastUtil;
import com.tuya.smart.home.sdk.bean.HomeBean;
import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.bean.TransferResultSummary;
import com.tuya.smart.lighting.sdk.impl.DefaultDeviceTransferListener;
import com.tuya.smart.sdk.api.bluemesh.ISigMeshCreateCallback;
import com.tuya.smart.sdk.api.bluemesh.ITuyaBlueMeshActivator;
import com.tuya.smart.sdk.bean.DeviceBean;
import com.tuya.smart.sdk.bean.SigMeshBean;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.tuya.smart.commercial.lighting.demo.common.IntentExtra.KEY_AREA_ID;
import static com.tuya.smart.commercial.lighting.demo.common.IntentExtra.KEY_PROJECT_ID;

public class SigMeshConfigActivity extends BaseActivity implements View.OnClickListener, ITuyaBlueMeshSearchListener {
    public static final String TAG = SigMeshConfigActivity.class.getSimpleName();
    private ITuyaBlueMeshSearch mMeshSearch;
    private TextView tv_result;
    private SearchDeviceBean deviceBean;
    private SigMeshBean mSigMeshBean;
    private DeviceBean mDeviceBean;
    private long areaId;
    private long projectId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        areaId = getIntent().getLongExtra(KEY_AREA_ID,-1);
        projectId = getIntent().getLongExtra(KEY_PROJECT_ID,-1);
        setContentView(R.layout.cl_activity_sig_mesh_config);
        findViewById(R.id.btn_sigmesh_search).setOnClickListener(this);
        findViewById(R.id.btn_sigmesh_config).setOnClickListener(this);
        findViewById(R.id.btn_sigmesh_area).setOnClickListener(this);
        findViewById(R.id.btn_sigmesh_create).setOnClickListener(this);
        tv_result = findViewById(R.id.tv_result);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_sigmesh_create:
                createSigMesh();
                break;
            case R.id.btn_sigmesh_search:
                // 搜索蓝牙设备
                searchSigMesh();
                break;
            case  R.id.btn_sigmesh_config:
                // 配网
                configDevice();
                break;
            case R.id.btn_sigmesh_area:
                // 分区
                setArea();
                break;
        }
    }

    private void createSigMesh() {
        if (projectId == -1){
            ToastUtil.showToast(this,"请从项目管理进入");
        }
        tv_result.setText("开始创建mesh");
        TuyaCommercialLightingSdk.getSigMeshInstance().createSigMesh(projectId, new ISigMeshCreateCallback() {
            @Override
            public void onError(String errorCode, String errorMsg) {

            }

            @Override
            public void onSuccess(SigMeshBean sigMeshBean) {
                tv_result.setText("mesh创建成功：mesdId = "+sigMeshBean.meshId);
                mSigMeshBean = sigMeshBean;
            }
        });
    }

    private void setArea() {
        if (mDeviceBean == null){
            ToastUtil.showToast(this,"请先配网成功");
            return;
        }

        if (areaId == -1){
            ToastUtil.showToast(this,"请从区域跳入配网，传入真实areaId");
            return;
        }


        List<String> devIds = new ArrayList<>();
        devIds.add(mDeviceBean.devId);
        tv_result.setText("正在分区中");
        ProgressUtil.showLoading(this,"开始分区中。。。");
        TuyaCommercialLightingSdk.newAreaInstance(projectId,areaId).transferDevices(devIds, new DefaultDeviceTransferListener() {
            @Override
            public void handleResult(TransferResultSummary transferResultSummary) {
                tv_result.setText("分区成功");
                ProgressUtil.hideLoading();
            }

            @Override
            public void onError(String errorMsg, String errorCode) {
                ProgressUtil.hideLoading();
                tv_result.setText("分区失败");
            }
        });
    }

    private void configDevice() {
        if (mMeshSearch != null){
            mMeshSearch.stopSearch();
        }
        if (mSigMeshBean == null){
            ToastUtil.shortToast(this,"请先创建mesh");
            return;
        }
        if (deviceBean == null){
            ToastUtil.shortToast(this,"暂无搜索到的设备");
            return;
        }


        tv_result.setText("开始配网");
        List<SearchDeviceBean> beans = new ArrayList<>();
        beans.add(deviceBean);
        ProgressUtil.showLoading(this,"开始配网中。。。");
        TuyaSigMeshActivatorBuilder tuyaSigMeshActivatorBuilder = new TuyaSigMeshActivatorBuilder()
                .setSearchDeviceBeans(beans)
                .setSigMeshBean(mSigMeshBean)
                .setTimeOut(60000)
                .setTuyaBlueMeshActivatorListener(new ITuyaBlueMeshActivatorListener() {
                    @Override
                    public void onSuccess(String mac, DeviceBean deviceBean) {
                        ToastUtil.shortToast(SigMeshConfigActivity.this,"配网成功");
                        tv_result.setText("配网成功！！！mac:"+mac+"---"+"name="+deviceBean.getName());
                        mDeviceBean = deviceBean;
                        getProjectDetail();

                    }

                    @Override
                    public void onError(String mac, String errorCode, String errorMsg) {
                        ToastUtil.shortToast(SigMeshConfigActivity.this,"配网失败");
                        tv_result.setText("配网失败");
                        ProgressUtil.hideLoading();
                    }

                    @Override
                    public void onFinish() {
                        tv_result.setText("配网结束");
                        ProgressUtil.hideLoading();
                    }
                });

        ITuyaBlueMeshActivator iTuyaBlueMeshActivator = TuyaCommercialLightingSdk.getTuyaBlueMeshConfig().newSigActivator(tuyaSigMeshActivatorBuilder);
        //开启配网
        iTuyaBlueMeshActivator.startActivator();

    }

    private void getProjectDetail() {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).getProjectDetail(new ITuyaHomeResultCallback() {
            @Override
            public void onSuccess(HomeBean bean) {
                ProgressUtil.hideLoading();
                TuyaCommercialLightingSdk.getTuyaSigMeshClient().startClient(mSigMeshBean);
            }

            @Override
            public void onError(String errorCode, String errorMsg) {
                ProgressUtil.hideLoading();
            }
        });

    }

    private void searchSigMesh() {
        tv_result.setText("开始搜索设备。。。");
        // 待配网的SigMesh设备UUID是固定的
        UUID[] MESH_PROVISIONING_UUID = {UUID.fromString("00001827-0000-1000-8000-00805f9b34fb")};
        SearchBuilder searchBuilder = new SearchBuilder()
                .setServiceUUIDs(MESH_PROVISIONING_UUID)    //SigMesh的UUID是固定值
                .setTimeOut(100)        //扫描时长 单位秒
                .setTuyaBlueMeshSearchListener(this).build();
        mMeshSearch = TuyaCommercialLightingSdk.getTuyaBlueMeshConfig().newTuyaBlueMeshSearch(searchBuilder);
        mMeshSearch.startSearch();
    }

    @Override
    public void onSearched(SearchDeviceBean deviceBean) {
        this.deviceBean = deviceBean;
        ToastUtil.shortToast(this,"搜索成功");
        tv_result.setText("搜索到的设备的mac地址："+ deviceBean.getMacAdress());
        if (mMeshSearch != null){
            mMeshSearch.stopSearch();
        }
    }

    @Override
    public void onSearchFinish() {
        ToastUtil.shortToast(this,"搜索结束");
    }
}