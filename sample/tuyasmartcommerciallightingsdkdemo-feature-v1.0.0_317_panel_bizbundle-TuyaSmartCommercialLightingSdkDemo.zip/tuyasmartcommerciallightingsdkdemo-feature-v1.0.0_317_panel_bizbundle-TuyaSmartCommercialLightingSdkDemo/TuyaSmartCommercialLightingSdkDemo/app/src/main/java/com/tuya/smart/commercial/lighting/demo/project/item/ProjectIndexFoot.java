package com.tuya.smart.commercial.lighting.demo.project.item;

import android.view.View;
import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseFoot;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;

import butterknife.BindView;

public class ProjectIndexFoot extends BaseFoot<String> {
    @BindView(R.id.project_index_add_txt)
    TextView addTxt;

    private String mTitleName;

    public ProjectIndexFoot(String title) {
        super("");
        this.mTitleName = title;
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recycler_project_index_foot;
    }

    @Override
    public void onReleaseViews(BaseViewHolder holder, int sectionKey, int sectionFootPosition) {

    }

    @Override
    public void onSetViewsData(BaseViewHolder holder, int sectionKey, int sectionFootPosition) {
        addTxt.setOnClickListener(mListener);
        addTxt.setText(mTitleName);
    }


    private View.OnClickListener mListener;

    public void setOnClickListener(View.OnClickListener listener) {
        mListener = listener;
    }
}
