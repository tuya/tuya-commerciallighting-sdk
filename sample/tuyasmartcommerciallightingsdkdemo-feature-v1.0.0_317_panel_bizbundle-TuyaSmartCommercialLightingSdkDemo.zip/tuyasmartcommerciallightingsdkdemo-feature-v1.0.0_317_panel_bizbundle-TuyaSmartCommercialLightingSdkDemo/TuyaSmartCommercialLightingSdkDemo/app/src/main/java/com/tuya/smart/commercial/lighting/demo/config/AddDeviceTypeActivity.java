package com.tuya.smart.commercial.lighting.demo.config;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.android.demo.base.activity.BaseActivity;
import com.tuya.smart.android.demo.base.utils.ActivityUtils;

import static com.tuya.smart.commercial.lighting.demo.common.IntentExtra.KEY_AREA_ID;
import static com.tuya.smart.commercial.lighting.demo.common.IntentExtra.KEY_PROJECT_ID;


public class AddDeviceTypeActivity extends BaseActivity {
    private long areaId;
    private long projectId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device_type);
        areaId = getIntent().getLongExtra(KEY_AREA_ID,-1);
        projectId = getIntent().getLongExtra(KEY_PROJECT_ID,-1);
        initToolbar();
        initView();
        setTitle(getString(R.string.ty_add_device_sort));
        setDisplayHomeAsUpEnabled();
    }

    private void initView() {
        findViewById(R.id.wifi_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWifiDevConfig();
            }
        });
        findViewById(R.id.gateway_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGatewayDevConfig();
            }
        });

        findViewById(R.id.sigmesh_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSigMeshDevConfig();
            }
        });
    }

    private void startSigMeshDevConfig() {
        Intent intent = new Intent(this,SigMeshConfigActivity.class);
        intent.putExtra(KEY_AREA_ID,areaId);
        intent.putExtra(KEY_PROJECT_ID,projectId);
        startActivity(intent);
    }

    private void startGatewayDevConfig() {
        Intent intent = new Intent(this,ZigbeeConfigActivity.class);
        intent.putExtra(KEY_AREA_ID,areaId);
        intent.putExtra(KEY_PROJECT_ID,projectId);
        startActivity(intent);
    }

    private void startWifiDevConfig() {
        Intent intent = new Intent(this,AddDeviceTipActivity.class);
        intent.putExtra(KEY_AREA_ID,areaId);
        intent.putExtra(KEY_PROJECT_ID,projectId);
        startActivity(intent);
    }
}
