package com.tuya.smart.commercial.lighting.demo.area.view;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.area.item.AreaIndexItemStyle1;
import com.tuya.smart.commercial.lighting.demo.area.presenter.AreaInfoPresenter;
import com.tuya.smart.commercial.lighting.demo.area.util.CreateAreaUtils;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.base.utils.DialogUtil;
import com.tuya.smart.commercial.lighting.demo.common.IntentExtra;
import com.tuya.smart.commercial.lighting.demo.device.DeviceListActivity;
import com.tuya.smart.commercial.lighting.demo.recyclerview.adapter.BaseRVAdapter;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.lighting.sdk.anno.AreaCategory;
import com.tuya.smart.lighting.sdk.anno.AreaCreateStatus;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

import static com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils.ANIMATE_SCALE_IN;

public class AreaInfoActivity extends BaseActivity implements IAreaInfoView {

    @BindView(R.id.area_info_rv)
    RecyclerView rv;
    @BindView(R.id.area_info_name)
    TextView tvName;
    @BindView(R.id.area_info_create_sub)
    Button btnCreateSub;
    @BindView(R.id.area_info_create_parent)
    Button btnCreateParent;

    private static final int AREA_INFO_REQUEST_CODE = 1;
    private AreaInfoPresenter mPresenter;
    private BaseRVAdapter<AreaIndexItemStyle1> mAdapter;
    private long mProjectId, mAreaId;
    Unbinder unbinder;

    private SimpleAreaBean currentAreaInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_area_info);
        unbinder = ButterKnife.bind(this);
        Intent intent = getIntent();
        mProjectId = intent.getLongExtra(IntentExtra.KEY_PROJECT_ID, 0);
        mAreaId = intent.getLongExtra(IntentExtra.KEY_AREA_ID, 0);
        initToolbar();
        initTitle();
        initAdapter();
        initListener();
        initPresenter();
    }

    private void initTitle() {
        setDisplayHomeAsUpEnabled();
        setTitle(getString(R.string.cl_area_info_title));
        mToolBar.setTitleTextColor(Color.WHITE);
    }

    private void initPresenter() {
        mPresenter = new AreaInfoPresenter(mProjectId, mAreaId, this);
    }

    private void initListener() {
        mAdapter.setOnItemViewClickListener((item, sectionKey, sectionItemPosition) -> {
            AreaBean itemData = item.getData();
            if (itemData.getRoomSource() == AreaCategory.CUSTOM_AREA) {
                Intent intent = new Intent(this, AreaInfoActivity.class);
                intent.putExtra(IntentExtra.KEY_PROJECT_ID, mProjectId);
                intent.putExtra(IntentExtra.KEY_AREA_ID, itemData.getAreaId());
                ActivityUtils.startActivityForResult(this, intent, AREA_INFO_REQUEST_CODE, ANIMATE_SCALE_IN, false);
            } else {
                showDeviceList();
            }
        });
    }

    private void initAdapter() {
        mAdapter = new BaseRVAdapter<>();
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(mAdapter);
    }

    @OnClick(R.id.btn_device_list)
    public void showDeviceList() {
        Intent intent = new Intent(this, DeviceListActivity.class);
        intent.putExtras(getIntent());
        startActivity(intent);
    }


    @OnClick(R.id.area_info_remove)
    public void deleteArea() {
        mPresenter.deleteArea();
    }

    @OnClick(R.id.area_info_name)
    public void updateAreaName() {
        DialogUtil.simpleInputDialog(this, getString(R.string.cl_area_edit_name), tvName.getText(), false, new DialogUtil.SimpleInputDialogInterface() {
            @Override
            public void onPositive(DialogInterface dialog, String inputText) {
                mPresenter.updateAreaName(inputText);
            }

            @Override
            public void onNegative(DialogInterface dialog) {
                dialog.dismiss();
            }
        });
    }

    @OnClick(R.id.btn_area_control)
    public void onAreaControlClick() {
        Intent intent = new Intent(this, AreaControlActivity.class);
        intent.putExtras(getIntent());
        startActivity(intent);
    }

    @OnClick(R.id.btn_device_config)
    public void onDeviceConfig() {
        ActivityUtils.gotoActivatorActivity(this, mProjectId, mAreaId);
    }

    @OnClick(R.id.area_info_create_sub)
    public void createSubArea() {
        CreateAreaUtils.createAreaDialog(this, new CreateAreaUtils.AreaInputDialogInterface() {
            @Override
            public void onPositive(DialogInterface dialog, long areaId, String areaName, int areaLevel) {
                mPresenter.createSubArea(areaName);
            }

            @Override
            public void onNegative(DialogInterface dialog) {
            }
        });
    }

    @OnClick(R.id.area_info_create_parent)
    public void createParentArea() {
        CreateAreaUtils.createAreaDialog(this, new CreateAreaUtils.AreaInputDialogInterface() {
            @Override
            public void onPositive(DialogInterface dialog, long areaId, String areaName, int areaLevel) {
                mPresenter.createParentArea(areaName);
            }

            @Override
            public void onNegative(DialogInterface dialog) {

            }
        });
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void setAreaData(SimpleAreaBean simpleAreaBean) {
        this.currentAreaInfo = simpleAreaBean;
        tvName.setText(simpleAreaBean.getName());
        switch (simpleAreaBean.getCanCreateStatus()) {
            case AreaCreateStatus.CREATE_CHILD_AND_PARENT_BOTH:
                btnCreateParent.setVisibility(View.VISIBLE);
                btnCreateSub.setVisibility(View.VISIBLE);
                break;
            case AreaCreateStatus.CREATE_CHILD_ONLY:
                btnCreateParent.setVisibility(View.GONE);
                btnCreateSub.setVisibility(View.VISIBLE);
                break;
            case AreaCreateStatus.CREATE_PARENT_ONLY:
                btnCreateParent.setVisibility(View.VISIBLE);
                btnCreateSub.setVisibility(View.GONE);
                break;
            case AreaCreateStatus.CREATE_DISABLE:
                btnCreateParent.setVisibility(View.GONE);
                btnCreateSub.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void setSubAreaList(List<AreaBean> subAreaList) {
        mAdapter.clearAllItemView();
        for (AreaBean item : subAreaList) {
            mAdapter.addItemView(new AreaIndexItemStyle1(item));
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void updateSuccess(String name) {
        setResult(RESULT_OK);
        tvName.setText(name);
    }

    @Override
    public void doRemoveView(boolean isSuccess) {
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void createSubSuccess(SimpleAreaBean simpleAreaBean) {
        AreaBean areaBean = new AreaBean();
        areaBean.setAreaId(simpleAreaBean.getAreaId());
        areaBean.setName(simpleAreaBean.getName());
        mAdapter.addItemView(new AreaIndexItemStyle1(areaBean));
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void createParentSuccess(SimpleAreaBean simpleAreaBean) {
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void createFailed(String content) {
        showToast(content);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AREA_INFO_REQUEST_CODE && resultCode == RESULT_OK) {
            mPresenter.getSubAreaList();
        }
    }
}