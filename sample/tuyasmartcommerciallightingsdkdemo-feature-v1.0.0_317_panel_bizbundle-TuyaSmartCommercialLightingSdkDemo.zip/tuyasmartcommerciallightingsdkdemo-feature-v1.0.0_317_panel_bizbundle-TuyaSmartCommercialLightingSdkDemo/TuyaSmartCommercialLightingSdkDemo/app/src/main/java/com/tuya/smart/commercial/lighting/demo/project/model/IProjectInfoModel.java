package com.tuya.smart.commercial.lighting.demo.project.model;

import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.sdk.api.IResultCallback;

public interface IProjectInfoModel {

    void getProjectDetail(long projectId, ITuyaHomeResultCallback callback);

    void getKeyFromPassword(String password, ITuyaResultCallback<String> callback);

    void updateProjectInfo(long projectId, String projectName, String leaderName, String leaderMobile, String detailAddress, final IResultCallback callback);

    void delete(long projectId, String key, IResultCallback callback);
}
