package com.tuya.smart.commercial.lighting.demo.project.presenter;


import com.tuya.smart.android.mvp.presenter.BasePresenter;
import com.tuya.smart.commercial.lighting.demo.project.model.IProjectInfoModel;
import com.tuya.smart.commercial.lighting.demo.project.model.ProjectInfoModel;
import com.tuya.smart.commercial.lighting.demo.project.view.IProjectInfoView;
import com.tuya.smart.home.sdk.bean.HomeBean;
import com.tuya.smart.home.sdk.callback.ITuyaHomeResultCallback;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.sdk.api.IResultCallback;

public class ProjectInfoPresenter extends BasePresenter {

    private IProjectInfoView mIProjectInfoView;

    private IProjectInfoModel mProjectInfoModel;

    private HomeBean mHomeBean;

    public ProjectInfoPresenter(IProjectInfoView view) {
        super(view.getContext());
        this.mIProjectInfoView = view;
        this.mProjectInfoModel = new ProjectInfoModel(view.getContext());

        getHomeInfo();
    }

    private void getHomeInfo() {
        mProjectInfoModel.getProjectDetail(mIProjectInfoView.getProjectId(), new ITuyaHomeResultCallback() {
            @Override
            public void onSuccess(HomeBean homeBean) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mHomeBean = homeBean;
                mIProjectInfoView.setProjectData(mHomeBean);

                if (homeBean.getSigMeshList() != null && homeBean.getSigMeshList().size() > 0) {
                    TuyaCommercialLightingSdk.getTuyaSigMeshClient().startClient(homeBean.getSigMeshList().get(0));
                }
            }

            @Override
            public void onError(String s, String s1) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(s1);
            }
        });
    }

    public void updateProjectName(String content) {
        mProjectInfoModel.updateProjectInfo(mHomeBean.getHomeId(), content, mHomeBean.getLeaderName(), mHomeBean.getLeaderMobile(), mHomeBean.getDetail(), new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(error);
            }

            @Override
            public void onSuccess() {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.updateProjectName(content);
            }
        });
    }

    public void updateLeaderName(String content) {
        mProjectInfoModel.updateProjectInfo(mHomeBean.getHomeId(), mHomeBean.getName(), content, mHomeBean.getLeaderMobile(), mHomeBean.getDetail(), new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(error);
            }

            @Override
            public void onSuccess() {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.updateLeaderName(content);
            }
        });
    }

    public void updateLeaderMobile(String content) {
        mProjectInfoModel.updateProjectInfo(mHomeBean.getHomeId(), mHomeBean.getName(), mHomeBean.getLeaderName(), content, mHomeBean.getDetail(), new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(error);
            }

            @Override
            public void onSuccess() {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.updateLeaderMobile(content);
            }
        });
    }

    public void updateAddressDetail(String content) {
        mProjectInfoModel.updateProjectInfo(mHomeBean.getHomeId(), mHomeBean.getName(), mHomeBean.getLeaderName(), mHomeBean.getLeaderMobile(), content, new IResultCallback() {
            @Override
            public void onError(String code, String error) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(error);
            }

            @Override
            public void onSuccess() {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.updateAddressDetail(content);
            }
        });
    }

    public void removeProject(String password) {
        mProjectInfoModel.getKeyFromPassword(password, new ITuyaResultCallback<String>() {
            @Override
            public void onSuccess(String result) {
                remove(result);
            }

            @Override
            public void onError(String errorCode, String errorMessage) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(errorMessage);
            }
        });

    }

    private void remove(String key) {
        mProjectInfoModel.delete(mIProjectInfoView.getProjectId(), key, new IResultCallback() {
            @Override
            public void onError(String s, String s1) {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.showToast(s1);
            }

            @Override
            public void onSuccess() {
                if (null == mIProjectInfoView) {
                    return;
                }
                mIProjectInfoView.doRemoveView(true);
            }
        });
    }


    @Override
    public void onDestroy() {
        mHomeBean = null;
        super.onDestroy();
    }
}
