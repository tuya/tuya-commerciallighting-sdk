package com.tuya.smart.commercial.lighting.demo.bean;


import com.tuya.smart.lighting.sdk.enums.AreaDpMode;
import com.tuya.smart.lighting.sdk.enums.LightDefaultSceneType;

public class AreaBeanDps {
    /** 开关状态 true-开  false-关 */
    private boolean switchStatus;

    /** 亮度百分比 */
    private int brightnessPercent;

    /** 色温百分比 */
    private int temperaturePercent;

    /** 颜色HSV */
    private String colorData;

    private AreaDpMode areaDpMode;

    /** 默认选中的场景类型 */
    private LightDefaultSceneType currentSceneType;

    public boolean getSwitchStatus() {
        return switchStatus;
    }

    public void setSwitchStatus(boolean switchStatus) {
        this.switchStatus = switchStatus;
    }

    public int getBrightnessPercent() {
        return brightnessPercent;
    }

    public void setBrightnessPercent(int brightnessPercent) {
        this.brightnessPercent = brightnessPercent;
    }

    public int getTemperaturePercent() {
        return temperaturePercent;
    }

    public void setTemperaturePercent(int temperaturePercent) {
        this.temperaturePercent = temperaturePercent;
    }

    public String getColorData() {
        return colorData;
    }

    public void setColorData(String colorData) {
        this.colorData = colorData;
    }

    public LightDefaultSceneType getCurrentSceneType() {
        return currentSceneType;
    }

    public void setCurrentSceneType(LightDefaultSceneType getCurrentSceneType) {
        this.currentSceneType = getCurrentSceneType;
    }

    public AreaDpMode getAreaDpMode() {
        return areaDpMode;
    }

    public void setAreaDpMode(AreaDpMode areaDpMode) {
        this.areaDpMode = areaDpMode;
    }
}
