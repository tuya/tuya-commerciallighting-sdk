package com.tuya.smart.commercial.lighting.demo.project.view;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.app.Constant;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.project.item.ProjectAddEditNameItem;
import com.tuya.smart.commercial.lighting.demo.project.presenter.ProjectAddPresenter;
import com.tuya.smart.commercial.lighting.demo.recyclerview.adapter.BaseRVAdapter;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseItem;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ProjectAddActivity extends BaseActivity implements IProjectAddView {

    @BindView(R.id.project_add_rv)
    RecyclerView rv;

    public static final String KEY_EMPTY_PROJECT = "empty_project_key";

    private ProjectAddPresenter mPresenter;

    private BaseRVAdapter<BaseItem> mAdapter;

    Unbinder unbinder;
    private ProjectAddEditNameItem mEditNameItem, mLeaderNameItem, mLeaderMobileItem, mDetailAddressItem;
    private boolean isEmptyProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_project_add);
        unbinder = ButterKnife.bind(this);
        isEmptyProject = getIntent().getBooleanExtra(KEY_EMPTY_PROJECT, false);
        initToolbar();
        initTitle();
        initAdapter();
        initListener();
        initPresenter();
    }

    private void initPresenter() {
        mPresenter = new ProjectAddPresenter(this);
    }

    private void initListener() {

    }

    private void initAdapter() {
        mAdapter = new BaseRVAdapter<>();
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(mAdapter);
        mEditNameItem = new ProjectAddEditNameItem(getString(R.string.cl_project_info_name));
        mLeaderNameItem = new ProjectAddEditNameItem(getString(R.string.cl_project_info_leader_name));
        mLeaderMobileItem = new ProjectAddEditNameItem(getString(R.string.cl_project_info_leader_mobile));
        mDetailAddressItem = new ProjectAddEditNameItem(getString(R.string.cl_project_info_address));
        mAdapter.addItemView(mEditNameItem);
        mAdapter.addItemView(mLeaderNameItem);
        mAdapter.addItemView(mLeaderMobileItem);
        mAdapter.addItemView(mDetailAddressItem);

    }

    private void initTitle() {
        setTitle(getString(R.string.cl_project_add_title));
        mToolBar.setTitleTextColor(Color.WHITE);
        setDisplayHomeAsUpEnabled();
        setMenu(R.menu.toolbar_save, item -> {
            if (item.getItemId() == R.id.action_menu_save) {
                checkParams();
            }
            return false;
        });
    }


    private void checkParams() {
        String projectName = mEditNameItem.getEditText();
        if (TextUtils.isEmpty(projectName)) {
            showToast(mEditNameItem.getTitleName() + getString(R.string.cl_project_add_item_check_tip));
            return;
        }
        String leaderName = mLeaderNameItem.getEditText();
        if (TextUtils.isEmpty(leaderName)) {
            showToast(mLeaderNameItem.getTitleName() + getString(R.string.cl_project_add_item_check_tip));
            return;
        }
        String leaderMobile = mLeaderMobileItem.getEditText();
        if (TextUtils.isEmpty(leaderMobile)) {
            showToast(mLeaderMobileItem.getTitleName() + getString(R.string.cl_project_add_item_check_tip));
            return;
        }
        String detailAddress = mDetailAddressItem.getEditText();
        if (TextUtils.isEmpty(detailAddress)) {
            showToast(mDetailAddressItem.getTitleName() + getString(R.string.cl_project_add_item_check_tip));
            return;
        }
        showLoading();
        mPresenter.addProject(projectName, leaderName, leaderMobile, detailAddress);
    }


    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void doSaveSuccess() {
        hideLoading();
        showToast(R.string.save_success);
        finishActivity();
        if (isEmptyProject) {
            Constant.finishActivity();
            ActivityUtils.gotoHomeActivity(this);
        }
    }

    @Override
    public void doSaveFailed() {
        hideLoading();
        showToast(R.string.save_failed);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != unbinder) {
            unbinder.unbind();
        }
        mPresenter.onDestroy();
    }
}
