package com.tuya.smart.commercial.lighting.demo.area.model;


import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.area.bean.AreaListInProjectResponse;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import java.util.List;

public interface IAreaIndexModel {

    void getAreaList(long projectId, ITuyaResultCallback<List<AreaBean>> callback);

    void getAreaLevels(long projectId, boolean needUnassignedArea, boolean needPublicArea, ITuyaResultCallback<AreaListInProjectResponse> callback);
}
