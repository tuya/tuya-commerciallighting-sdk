package com.tuya.smart.commercial.lighting.demo.base.widget.contact;

public interface ContactItemInterface {

    String getItemForIndex();

    String getNumber();

    String getKey();
}
