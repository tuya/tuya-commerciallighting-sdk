package com.tuya.smart.commercial.lighting.demo.login.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.tuya.smart.android.demo.R;
import com.tuya.smart.android.user.api.ILoginCallback;
import com.tuya.smart.android.user.bean.User;
import com.tuya.smart.commercial.lighting.demo.app.Constant;
import com.tuya.smart.commercial.lighting.demo.base.activity.BaseActivity;
import com.tuya.smart.commercial.lighting.demo.base.utils.ActivityUtils;
import com.tuya.smart.commercial.lighting.demo.base.utils.LoginHelper;
import com.tuya.smart.commercial.lighting.demo.base.utils.ToastUtil;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class LoginWithUidActivity extends BaseActivity {
    private Unbinder mBind;

    @BindView(R.id.et_uid)
    public EditText mUidEditText;

    @BindView(R.id.et_password)
    public EditText mPasswordEditText;

    @BindView(R.id.btn_login)
    public Button mLoginButton;

    @BindView(R.id.tv_login_result)
    public TextView mLoginResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cl_activity_login_with_uid);
        mBind = ButterKnife.bind(this);
    }

    @Override
    public boolean needLogin() {
        return false;
    }

    @OnClick(R.id.btn_login)
    public void loginWithUid() {
        String content = mUidEditText.getText().toString().trim();
        String password = mPasswordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(content)) {
            ToastUtil.showToast(this, "请输入UID");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            ToastUtil.showToast(this, "请输入密码");
            return;
        }

        TuyaCommercialLightingSdk.getLightingUserManager().loginWithUid(content, "86", password, new ILoginCallback() {
            @Override
            public void onSuccess(User user) {
                ToastUtil.showToast(LoginWithUidActivity.this, "登录成功");
                mLoginResult.setText(JSON.toJSONString(user));

                Constant.finishActivity();
                LoginHelper.afterLogin();
                ActivityUtils.gotoHomeActivity(LoginWithUidActivity.this);
            }

            @Override
            public void onError(String code, String error) {
                ToastUtil.showToast(LoginWithUidActivity.this, "登录失败：" + error);
            }
        });
    }

    @OnClick(R.id.btn_login_with_username)
    public void loginWithUserName() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finishActivity();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mBind.unbind();
    }
}
