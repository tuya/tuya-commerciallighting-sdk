package com.tuya.smart.commercial.lighting.demo.area.item;

import android.widget.TextView;

import com.tuya.smart.android.demo.R;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseItem;
import com.tuya.smart.commercial.lighting.demo.recyclerview.item.BaseViewHolder;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import butterknife.BindView;

public class AreaIndexItemStyle1 extends BaseItem<AreaBean> {

    @BindView(R.id.recycler_area_item_name)
    TextView tvName;

    public AreaIndexItemStyle1(AreaBean data) {
        super(data);
    }

    @Override
    public int getViewType() {
        return 0;
    }

    @Override
    public int getLayoutId(int viewType) {
        return R.layout.cl_recycler_area_index_item;
    }

    @Override
    public void onReleaseViews(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {

    }

    @Override
    public void onSetViewsData(BaseViewHolder holder, int sectionKey, int sectionViewPosition) {
        tvName.setText(getData().getName());
    }
}
