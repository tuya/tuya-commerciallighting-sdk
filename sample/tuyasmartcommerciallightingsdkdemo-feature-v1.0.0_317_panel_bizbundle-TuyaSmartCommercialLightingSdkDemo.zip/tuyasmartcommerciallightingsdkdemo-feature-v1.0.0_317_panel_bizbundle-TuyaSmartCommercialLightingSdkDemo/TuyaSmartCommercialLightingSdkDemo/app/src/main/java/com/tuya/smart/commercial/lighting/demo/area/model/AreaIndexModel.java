package com.tuya.smart.commercial.lighting.demo.area.model;


import android.content.Context;

import com.tuya.smart.android.mvp.model.BaseModel;
import com.tuya.smart.home.sdk.bean.SimpleAreaBean;
import com.tuya.smart.home.sdk.callback.ITuyaResultCallback;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.area.bean.AreaListInProjectResponse;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

import java.util.List;

public class AreaIndexModel extends BaseModel implements IAreaIndexModel {

    public static final String TAG = AreaIndexModel.class.getSimpleName();

    public AreaIndexModel(Context ctx) {
        super(ctx);
    }

    @Override
    public void getAreaList(long projectId, ITuyaResultCallback<List<AreaBean>> callback) {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).getAreaList(callback);
    }

    @Override
    public void getAreaLevels(long projectId, boolean needUnassignedArea, boolean needPublicArea, ITuyaResultCallback<AreaListInProjectResponse> callback) {
        TuyaCommercialLightingSdk.newProjectInstance(projectId).getAreaLevels(needUnassignedArea, needPublicArea, callback);
    }

    @Override
    public void onDestroy() {

    }
}
