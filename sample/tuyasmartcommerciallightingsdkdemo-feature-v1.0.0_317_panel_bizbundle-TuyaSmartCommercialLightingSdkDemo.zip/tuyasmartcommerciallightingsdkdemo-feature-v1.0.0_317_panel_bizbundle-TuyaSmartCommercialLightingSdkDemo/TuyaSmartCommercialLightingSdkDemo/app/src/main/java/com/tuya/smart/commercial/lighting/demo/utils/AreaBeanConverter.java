package com.tuya.smart.commercial.lighting.demo.utils;

import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanDps;
import com.tuya.smart.commercial.lighting.demo.bean.AreaBeanWrapper;
import com.tuya.smart.lighting.sdk.TuyaCommercialLightingSdk;
import com.tuya.smart.lighting.sdk.api.ILightingStandardAreaDpsManager;
import com.tuya.smart.lighting.sdk.bean.AreaBean;

public class AreaBeanConverter {

    public static AreaBeanWrapper convertAreaBean2Wrapper(long projectId, AreaBean bean) {
        AreaBeanWrapper wrapper = new AreaBeanWrapper(bean);
        AreaBeanDps areaDps = getAreaBeanDps(projectId, bean);

        if (areaDps != null) {
            wrapper.setBrightness(areaDps.getBrightnessPercent());
            wrapper.setSwitchOpen(areaDps.getSwitchStatus());
            wrapper.setCurrentSceneType(areaDps.getCurrentSceneType());
            wrapper.setTemperaturePercent(areaDps.getTemperaturePercent());
            wrapper.setAreaDpMode(areaDps.getAreaDpMode());
            wrapper.setColorData(areaDps.getColorData());
            wrapper.setDps(bean.getDps());
            wrapper.setName(bean.getName());
        }
        return wrapper;
    }

    /**
     * 获取区域dps
     *
     * @param areaBean
     */
    public static AreaBeanDps getAreaBeanDps(long projectId, AreaBean areaBean) {
        AreaBeanDps areaBeanDps = new AreaBeanDps();
        try {
            ILightingStandardAreaDpsManager areaDpsManager = TuyaCommercialLightingSdk
                    .newAreaInstance(projectId, areaBean.getAreaId()).getLightingStandardAreaDpsManagerInstance();
            areaBeanDps.setBrightnessPercent(areaDpsManager.getBrightPercent());
            areaBeanDps.setSwitchStatus(areaDpsManager.getSwitchStatus());
            areaBeanDps.setTemperaturePercent(areaDpsManager.getTemperaturePercent());
            areaBeanDps.setAreaDpMode(areaDpsManager.getCurrentMode());
            areaBeanDps.setCurrentSceneType(areaDpsManager.getSceneStatus());
            areaBeanDps.setColorData(areaDpsManager.getColorData());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return areaBeanDps;
    }
}
